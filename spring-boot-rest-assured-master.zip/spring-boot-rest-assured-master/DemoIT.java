package com.ppv.ms.sample.api.controllers;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static io.restassured.RestAssured.get;
import static org.hamcrest.CoreMatchers.is;

@SpringBootTest(webEnvironment= SpringBootTest.WebEnvironment.RANDOM_PORT)
public class DemoIT {

    @Test
    public void testCustomerList() {

        get("http://localhost:8080/list")
                .then()
                .assertThat()
                .statusCode(200)
                .body("size()", is(2));


        get("http://localhost:8080/one/0")
                .then()
                .assertThat()
                .statusCode(200)
                .body("name", Matchers.equalTo("frank"));

        get("http://localhost:8080/one/1")
                .then()
                .assertThat()
                .statusCode(200)
                .body("name", Matchers.equalTo("john"));

    }

}
